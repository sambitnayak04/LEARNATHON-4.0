# Placeholder for simulate_data.py

import pandas as pd
import numpy as np
import random

def generate_transaction_data(n=1000, seed=42):
    random.seed(seed)
    np.random.seed(seed)

    data = {
        'transaction_id': [f'TX{i}' for i in range(n)],
        'amount': np.random.normal(loc=5000, scale=2000, size=n).astype(int),
        'transaction_type': np.random.choice(['purchase', 'transfer', 'withdrawal'], size=n),
        'timestamp': pd.date_range(start='2023-01-01', periods=n, freq='H'),
        'location': np.random.choice(['Delhi', 'Mumbai', 'Kolkata', 'Chennai', 'Bangalore'], size=n),
        'device_id': np.random.randint(1000, 9999, size=n),
        'account_age_days': np.random.randint(10, 2000, size=n),
        'num_failed_logins': np.random.poisson(1, size=n),
        'avg_transaction_amount': np.random.normal(4500, 1500, size=n).astype(int),
        'is_foreign_transaction': np.random.choice([0, 1], size=n, p=[0.85, 0.15]),
        'is_high_risk_country': np.random.choice([0, 1], size=n, p=[0.90, 0.10]),
        'merchant_id': np.random.randint(1, 300, size=n),
        'is_weekend': np.random.choice([0, 1], size=n),
        'prev_fraud_count': np.random.poisson(0.2, size=n)
    }

    df = pd.DataFrame(data)

    # Generate labels (is_fraud)
    df['is_fraud'] = (
        (df['amount'] > 15000) |
        (df['num_failed_logins'] > 3) |
        (df['is_foreign_transaction'] == 1) |
        (df['is_high_risk_country'] == 1) |
        (df['prev_fraud_count'] > 1)
    ).astype(int)

    df.to_csv('bankA_transactions.csv', index=False)
    print("✅ Sample transaction data generated as 'bankA_transactions.csv'")

if __name__ == "__main__":
    generate_transaction_data()
